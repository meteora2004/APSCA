import java.util.Scanner; 

class Main {
  public static void main(String[] args) {
    System.out.println ("WELCOME TO WORDLE!");
    Scanner sc = new Scanner(System.in); 
    HiddenWord hiddenWord = new HiddenWord("SHIRT"); 
    for (int i=0; i<6; i++ ){
      System.out.println("Please type your word");
      String guess = sc.next();
      guess = guess.toUpperCase();
      String hidden = hiddenWord.getHint(guess);
      System.out.println(hidden);
    }
  }
}