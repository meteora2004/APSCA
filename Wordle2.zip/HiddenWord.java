public class HiddenWord {
  private String word;
  //private int count;
  
  public HiddenWord(String wordIn){
    word = wordIn;
    //count = countIn;
  }
  public String getWord(){
    return word;
  }

  public String getHint(String guess){
    String hint = new String();
    for (int i=0; i<word.length(); i++){
      String letter = word.substring(i,i+1);
      String letter2 = guess.substring(i,i+1);
      if (letter.equals(letter2)){
        hint+= letter;
      }
      else if (word.indexOf(letter2) != -1){
        hint += "+";
      }
      else{
        hint += "*";
      }

    }
      return hint;
  }
  

}



