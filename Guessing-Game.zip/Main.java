import java.util.Scanner;

public class Main 
{
  public static void main(String[] args) 
  {
    Scanner scan = new Scanner(System.in);
   // Choose a random number from 0-100 
    int random =  (int) (Math.random()*101);

 

   // Ask the user to guess a number from 0 to 100 
   // Get the first guess using scan.nextInt();
      System.out.print("Guess a number from 0 to 100");
      int g = scan.nextInt();

 

   // Loop while the guess does not equal the random number,
      while(random !=g) {
     // If the guess is less than the random number, print out "Too low!"
        if (g < random){
          System.out.println("Too low bozo");
        }
     // If the guess is greater than the random number, print out "Too high!"
        if (g > random){
          System.out.println("Too high bozo");
        }
     // Get a new guess (save it into the same variable)
          g = scan.nextInt();
      }
      System.out.println("You got it right lmao");
  // Print out something like "You got it!"


  }
}